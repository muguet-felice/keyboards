%TF.GenerationSoftware,KiCad,Pcbnew,10.0.1*%
%TF.CreationDate,2026-06-24T16:46:20+09:00*%
%TF.ProjectId,MIKB26-MCK01-BP1,4d494b42-3236-42d4-9d43-4b30312d4250,rev?*%
%TF.SameCoordinates,Original*%
%TF.FileFunction,Soldermask,Top*%
%TF.FilePolarity,Negative*%
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 10.0.1) date 2026-06-24 16:46:20*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
%ADD10C,3.200000*%
G04 APERTURE END LIST*
D10*
%TO.C,REF2*%
X113000000Y-40000000D03*
%TD*%
%TO.C,REF3*%
X113000000Y-86000000D03*
%TD*%
%TO.C,REF1*%
X43000000Y-40000000D03*
%TD*%
%TO.C,REF4*%
X43000000Y-86000000D03*
%TD*%
M02*
